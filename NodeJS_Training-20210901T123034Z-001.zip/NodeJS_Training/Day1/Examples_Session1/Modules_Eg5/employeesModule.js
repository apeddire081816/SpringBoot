// FileName  :    EmployeeModule.js
exports.getEmps = function () 
{    
    let empsArray =  [
        { empno : 1025,  ename : "Scott", job : "Manager", deptno : 10 },
        { empno : 1026,  ename : "Smith", job : "Lead", deptno : 30 },
        { empno : 1027,  ename : "Sandy", job : "Sr.Programmer", deptno : 20 },
        { empno : 1028,  ename : "Sam", job : "Jr.Programmer", deptno : 40 },
        { empno : 1029,  ename : "Anu", job : "Jr.Programmer", deptno : 10 },
    ];

	return empsArray;
};




 

