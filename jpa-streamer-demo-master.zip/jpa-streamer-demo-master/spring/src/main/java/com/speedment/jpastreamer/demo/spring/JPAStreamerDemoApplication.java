package com.speedment.jpastreamer.demo.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JPAStreamerDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(JPAStreamerDemoApplication.class);
    }
}
